#pragma once
#include "node.h"
#include "rotatenode.h"
#include "scalenode.h"
#include "translatenode.h"
#include <QMainWindow>
#include <QTreeWidgetItem>


namespace Ui {
class MainWindow;
}


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_actionQuit_triggered();

private:
    Ui::MainWindow *ui;

public slots:
    void addTreeWidget(Node* n);
    void selectTreeItem(QTreeWidgetItem* current,
                        QTreeWidgetItem* previous);
    void changeScaleNodeX(int i);
    void changeScaleNodeY(int i);
    void changeTraNodeX(int i);
    void changeTraNodeY(int i);
    void changeRoNodeX(int i);
    void btnAddSquare();
};
