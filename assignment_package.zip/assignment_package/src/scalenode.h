#ifndef SCALENODE_H
#define SCALENODE_H

#include <node.h>
using namespace std;
using namespace glm;

class ScaleNode : public Node
{
private:
    float x , y;

public:
    //ScaleNode();
    ScaleNode(Polygon2D *Geo, glm::vec3 c, QString name, float a, float b);
    mat3 Transformation();
    float getX();
    float getY();
    void setX(float a);
    void setY(float b);
    ~ScaleNode();
};

#endif // SCALENODE_H
