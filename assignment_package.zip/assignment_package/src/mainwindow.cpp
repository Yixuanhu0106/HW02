#include "mainwindow.h"
#include "rotatenode.h"
#include "scalenode.h"
#include "translatenode.h"
#include <iostream>
#include <ui_mainwindow.h>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->mygl->setFocus();

    connect(ui->spinBox_S_X,SIGNAL(valueChanged(int)), this, SLOT(changeScaleNodeX(int)));
    connect(ui->spinBox_S_Y,SIGNAL(valueChanged(int)), this, SLOT(changeScaleNodeY(int)));
    connect(ui->spinBox_T_X,SIGNAL(valueChanged(int)), this, SLOT(changeTraNodeX(int)));
    connect(ui->spinBox_T_Y,SIGNAL(valueChanged(int)), this, SLOT(changeTraNodeY(int)));
    connect(ui->spinBox_R,SIGNAL(valueChanged(int)), this, SLOT(changeRoNodeX(int)));

    connect(ui->pushButton_Square, SIGNAL(released()), this, SLOT(btnAddSquare()));
    connect(ui->mygl,SIGNAL(RootNode(Node*)),this,SLOT(addTreeWidget(Node*)));//TreeWidget
    connect(ui->treeWidget,SIGNAL(currentItemChanged(QTreeWidgetItem *, QTreeWidgetItem *)),
            this, SLOT(selectTreeItem(QTreeWidgetItem*,QTreeWidgetItem*)));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionQuit_triggered()
{
    QApplication::exit();
}

void MainWindow::addTreeWidget(Node *n)
{
    ui->treeWidget->addTopLevelItem(n);
}

void MainWindow::selectTreeItem(QTreeWidgetItem *current, QTreeWidgetItem *previous)
{
    //cout<<(typeid(current)).name()<<" "<<(typeid(ScaleNode)).name()<<endl;
    ui->spinBox_R->setValue(0);
    ui->spinBox_S_X->setValue(0);
    ui->spinBox_S_Y->setValue(0);
    ui->spinBox_T_X->setValue(0);
    ui->spinBox_T_Y->setValue(0);


    if(dynamic_cast<ScaleNode*>(current) != nullptr)
    {
        ScaleNode* c = dynamic_cast<ScaleNode*>(current);
        ui->spinBox_S_X->setValue(c->getX());
        ui->spinBox_S_Y->setValue(c->getY());
    }
    if(dynamic_cast<TranslateNode*>(current) != nullptr)
    {
        TranslateNode* c = dynamic_cast<TranslateNode*>(current);
        ui->spinBox_T_X->setValue(c->getX());
        ui->spinBox_T_Y->setValue(c->getY());
    }
    if(dynamic_cast<RotateNode*>(current) != nullptr)
    {
        RotateNode* c = dynamic_cast<RotateNode*>(current);
        ui->spinBox_R->setValue(c->getR());
    }
    //emit ui->spinBox_R->valueChanged(ui->spinBox_R->value());
}

void MainWindow::changeScaleNodeX(int i)
{
    QTreeWidgetItem* current = ui->treeWidget->currentItem();
    if(dynamic_cast<ScaleNode*>(current) != nullptr)
        dynamic_cast<ScaleNode*>(current)->setX(i);
}

void MainWindow::changeScaleNodeY(int i)
{
    QTreeWidgetItem* current = ui->treeWidget->currentItem();
    if(dynamic_cast<ScaleNode*>(current) != nullptr)
        dynamic_cast<ScaleNode*>(current)->setY(i);
}

void MainWindow::changeTraNodeX(int i)
{
    QTreeWidgetItem* current = ui->treeWidget->currentItem();
    if(dynamic_cast<TranslateNode*>(current) != nullptr)
        dynamic_cast<TranslateNode*>(current)->setX(i);
}

void MainWindow::changeTraNodeY(int i)
{
    QTreeWidgetItem* current = ui->treeWidget->currentItem();
    if(dynamic_cast<TranslateNode*>(current) != nullptr)
        dynamic_cast<TranslateNode*>(current)->setY(i);
}

void MainWindow::changeRoNodeX(int i)
{
    QTreeWidgetItem* current = ui->treeWidget->currentItem();
    if(dynamic_cast<RotateNode*>(current) != nullptr)
        dynamic_cast<RotateNode*>(current)->setR(i);
}

void MainWindow::btnAddSquare()
{
    QTreeWidgetItem* current = ui->treeWidget->currentItem();
    Node* n = dynamic_cast<Node*>(current);
    if(!n->getGeometry()){
        Polygon2D* geo = new Polygon2D(ui->mygl,{glm::vec3(0.5f, 0.5f, 1.f),
                                                 glm::vec3(-0.5f, 0.5f, 1.f),
                                                 glm::vec3(-0.5f, -0.5f, 1.f),
                                                 glm::vec3(0.5f, -0.5f, 1.f)});
        n->setGeometry(geo);
    }
}
