#ifndef ROTATENODE_H
#define ROTATENODE_H

#include <node.h>

class RotateNode : public Node
{
private:
    float r; //rotating degree

public:
//    RotateNode();
    RotateNode(Polygon2D *Geo, glm::vec3 c, QString name, float a);
    mat3 Transformation();
    float getR();
    void setR(float a);
    ~RotateNode();
};

#endif // ROTATENODE_H
