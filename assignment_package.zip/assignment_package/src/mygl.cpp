#include "mygl.h"
#include "node.h"
#include "rotatenode.h"
#include "scalenode.h"
#include "translatenode.h"
#include <la.h>
#include <glm/vec3.hpp>
#include <glm/mat3x3.hpp>

#include <iostream>
#include <QApplication>
#include <QKeyEvent>


MyGL::MyGL(QWidget *parent)
    : OpenGLContext(parent),
      prog_flat(this),
      m_geomGrid(this), m_geomSquare(this, {glm::vec3(0.5f, 0.5f, 1.f),
                                            glm::vec3(-0.5f, 0.5f, 1.f),
                                            glm::vec3(-0.5f, -0.5f, 1.f),
                                            glm::vec3(0.5f, -0.5f, 1.f)}),
      m_showGrid(true), m_geomCircle(this, 10)
{
    setFocusPolicy(Qt::StrongFocus);
}

MyGL::~MyGL()
{
    makeCurrent();

    glDeleteVertexArrays(1, &vao);
    m_geomSquare.destroy();
    m_geomCircle.destroy();
    m_geomGrid.destroy();
}

void MyGL::initializeGL()
{
    // Create an OpenGL context using Qt's QOpenGLFunctions_3_2_Core class
    // If you were programming in a non-Qt context you might use GLEW (GL Extension Wrangler)instead
    initializeOpenGLFunctions();
    // Print out some information about the current OpenGL context
    debugContextVersion();

    // Set a few settings/modes in OpenGL rendering
//    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
    // Set the size with which points should be rendered
    glPointSize(5);
    // Set the color with which the screen is filled at the start of each render call.
    glClearColor(0.5, 0.5, 0.5, 1);

    printGLErrorLog();

    // Create a Vertex Attribute Object
    glGenVertexArrays(1, &vao);

    //Create the scene geometry
    m_geomGrid.create();
    m_geomSquare.create();
    m_geomCircle.create();

    // Create and set up the flat lighting shader
    prog_flat.create(":/glsl/flat.vert.glsl", ":/glsl/flat.frag.glsl");

    // We have to have a VAO bound in OpenGL 3.2 Core. But if we're not
    // using multiple VAOs, we can just bind one once.
    glBindVertexArray(vao);

    Root  = ConstructSceneGraph();

    emit RootNode(Root); //for the TreeWidget


}

Node* MyGL::ConstructSceneGraph()//constructs your entire scene graph and returns its root node, use "new"
{
    //Create some parameters and use them to construct a Node
    Node* root = new TranslateNode(nullptr, glm::vec3(1,1,1), "root", 0, 0);
    Node* body = new ScaleNode(&m_geomSquare,vec3(0, 0.5, 0.5), "body", 1, 2);
    Node* head = new TranslateNode(&m_geomCircle,vec3(1, 0, 0), "head", 0, 1.5);
    root->AddChild(body);
    root->AddChild(head);

    //Arms
    Node* r_arm_s = new ScaleNode(nullptr,vec3(0, 0.5, 0.5), "r_arm_s", 0.3, 1.5);
    Node* r_arm_r = new RotateNode(nullptr, vec3(0, 0.5, 0.5), "r_arm_r", 15);
    Node* r_arm_t = new TranslateNode(&m_geomSquare,vec3(0, 0.5, 0.5), "r_arm_t", 0.7, 0);
    root->AddChild(r_arm_s);
    r_arm_s->AddChild(r_arm_r);
    r_arm_r->AddChild(r_arm_t);

    Node* l_arm_s = new ScaleNode(nullptr,vec3(0, 0.5, 0.5), "l_arm_s", 0.3, 1.5);
    Node* l_arm_r = new RotateNode(nullptr, vec3(0, 0.5, 0.5), "l_arm_r", -15);
    Node* l_arm_t = new TranslateNode(&m_geomSquare,vec3(0, 0.5, 0.5), "l_arm_t", -0.7, 0);
    root->AddChild(l_arm_s);
    l_arm_s->AddChild(l_arm_r);
    l_arm_r->AddChild(l_arm_t);




    return root;

}
void MyGL::resizeGL(int w, int h)
{
    glm::mat3 viewMat = glm::scale(glm::mat3(), glm::vec2(0.2, 0.2)); // Screen is -5 to 5

    // Upload the view matrix to our shader (i.e. onto the graphics card)
    prog_flat.setViewMatrix(viewMat);

    printGLErrorLog();
}

//This function is called by Qt any time your GL window is supposed to update
//For example, when the function updateGL is called, paintGL is called implicitly.
void MyGL::paintGL()
{
    // Clear the screen so that we only see newly drawn images
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    if (m_showGrid)
    {
        prog_flat.setModelMatrix(glm::mat3());
        prog_flat.draw(*this, m_geomGrid);
    }


    //Testing one geometry, m should be identity matrix
    mat3 m_identity = mat3();
    this->traversal(Root, m_identity);

}

void MyGL::traversal(Node* n, mat3 m)
{
    mat3 m_t = n->Transformation() * m;


    if(!n->getChildren().empty()){
        for(Node* child : n->getChildren()){
            traversal(child, m_t);
        }
    }

    if(n->getGeometry()){
        vec3 c = n->getColor();
        n->getGeometry()->setColor(c);
        prog_flat.setModelMatrix(m_t);
        prog_flat.draw(*this, *(n->getGeometry()));
    }
}

void MyGL::keyPressEvent(QKeyEvent *e)
{
    // http://doc.qt.io/qt-5/qt.html#Key-enum
    switch(e->key())
    {
    case(Qt::Key_Escape):
        QApplication::quit();
        break;

    case(Qt::Key_G):
        m_showGrid = !m_showGrid;
        break;
    }
}

void MyGL::setSNodeX(int n)
{

}
