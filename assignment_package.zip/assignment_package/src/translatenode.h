#ifndef TRANSLATENODE_H
#define TRANSLATENODE_H

#include <node.h>
using namespace std;
using namespace glm;

class TranslateNode : public Node
{
private:
    float x, y;

public:
    //TranslateNode();
    TranslateNode(Polygon2D *Geo, glm::vec3 c, QString name, float a, float b);
    mat3 Transformation();
    float getX();
    float getY();
    void setX(float a);
    void setY(float b);
    ~TranslateNode();
};

#endif // TRANSLATENODE_H
