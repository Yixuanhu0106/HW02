#include "rotatenode.h"
#include "math.h"
#include <iostream>

//RotateNode::RotateNode()
//    : r(0) {}

RotateNode::RotateNode(Polygon2D *Geo, vec3 c, QString name, float a)
    : Node(Geo, c, name), r(a)
{
    QTreeWidgetItem::setText(0,name);
}

mat3 RotateNode::Transformation()
{
    mat3 m = mat3();
    float rad = r * M_PI / 180;
    m[0][0] = cos(rad);
    m[0][1] = sin(rad);
    m[1][0] = -sin(rad);
    m[1][1] = cos(rad);
    return m;
}

float RotateNode::getR()
{
    return r;
}

void RotateNode::setR(float a)
{
    r = a;
}

RotateNode::~RotateNode()
{
    cout<<"Destructing Rotate Node"<<endl;
}
