#ifndef NODE_H
#define NODE_H

#include <QObject>
#include <QTreeWidgetItem>
#include <glm/vec3.hpp>
#include <glm/mat3x3.hpp>
#include "scene/polygon.h"

using namespace std;
using namespace glm;

class Node : public QTreeWidgetItem
{
private:
    vector<Node*> children; //pointers storing node's children
    Polygon2D* geometry; //HELP NEEDED: a pointer to geometry
    vec3 color;//HELP NEEDED: do I need to define vec3?
    QString name;

public:
    //Node();
    Node(Polygon2D* Geo, glm::vec3 c, QString n);
    Polygon2D* getGeometry();
    void setGeometry(Polygon2D* p);
    void AddChild(Node* n);
    vector<Node*> getChildren();
    vec3 getColor();
    void setColor(vec3 c);
    virtual mat3 Transformation() = 0;
    virtual ~Node();//virtual destructor
};

#endif // NODE_H
