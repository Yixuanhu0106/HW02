#include "node.h"
#include <QTreeWidgetItem>
#include <iostream>
#include <glm/vec3.hpp>
#include <glm/mat3x3.hpp>

using namespace std;
using namespace glm;

//Node::Node()
//    : geometry(null), color(vec3(1,1,1)), name(QString("default")){}

Node::Node(Polygon2D *Geo, glm::vec3 c, QString n)
    : geometry(Geo), color(c), name(n)
{
    QTreeWidgetItem::setText(1,n);
}

Polygon2D* Node::getGeometry()
{
    return this->geometry;
}

void Node::AddChild(Node *n)
{
    children.push_back(n);
    QTreeWidgetItem::addChild(n);
}
vector<Node*> Node::getChildren()
{
    return children;
}

vec3 Node::getColor()
{
    return this->color;
}

void Node::setColor(vec3 c)
{
    color = c;
}

void Node::setGeometry(Polygon2D *p)
{
    geometry = p;
}


Node::~Node()
{
    cout<<"Destructing node"<<endl;
    for(int i = 0; i< children.size() - 1; i++){
        delete children[i];
    }
}


