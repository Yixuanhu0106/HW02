#include "scalenode.h"
#include <iostream>

//ScaleNode::ScaleNode()
//    : x(1), y(1) {} //0 would be nothing

ScaleNode::ScaleNode(Polygon2D *Geo, vec3 c, QString name, float a, float b)
    : Node(Geo, c, name), x(a), y(b)
{
    QTreeWidgetItem::setText(0,name);
}


mat3 ScaleNode::Transformation()
{
    mat3 m = mat3();
    m[0][0] = x;
    m[1][1] = y;
    return m;
}

float ScaleNode::getX()
{
    return x;
}

float ScaleNode::getY()
{
    return y;
}

void ScaleNode::setX(float a)
{
    x = a;
}

void ScaleNode::setY(float b)
{
    y = b;
}

ScaleNode::~ScaleNode()
{
     cout<<"Destructing Scale Node"<<endl;
}
