#include "translatenode.h"
#include <iostream>
using namespace std;
using namespace glm;



//TranslateNode::TranslateNode()
//    : x(0), y(0) {}

TranslateNode::TranslateNode(Polygon2D *Geo, vec3 c, QString name, float a, float b)
    : Node(Geo, c, name), x(a), y(b)
{
    QTreeWidgetItem::setText(0,name);
}

mat3 TranslateNode::Transformation()
{
    mat3 m = mat3();
    m[2][0] = x;
    m[2][1] = y;
    return m;
}
float TranslateNode::getX()
{
    return x;
}

float TranslateNode::getY()
{
    return y;
}

void TranslateNode::setX(float a)
{
    x = a;
}

void TranslateNode::setY(float b)
{
    y = b;
}

TranslateNode::~TranslateNode()
{
    cout<<"Destructing Translate Node"<<endl;
}
